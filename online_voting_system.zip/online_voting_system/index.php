<?php
include "includes/header_public.php";
?>

<div class="auth-container">
    <h2>Online Voting System</h2>

    <p style="text-align:center; margin-bottom:20px;">
        Secure • Transparent • Easy Voting
    </p>

    <a href="login.php" class="btn btn-primary" style="width:100%; margin-bottom:10px;">
        Login
    </a>

    <a href="register.php" class="btn btn-info" style="width:100%;">
        Register
    </a>
</div>

<?php include "includes/footer.php"; ?>
