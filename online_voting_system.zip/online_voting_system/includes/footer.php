<footer>© Online Voting System</footer>
</body>
</html>
