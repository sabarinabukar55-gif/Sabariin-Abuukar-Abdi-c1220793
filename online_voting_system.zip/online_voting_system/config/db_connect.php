<?php
$conn = mysqli_connect("localhost", "root", "", "online_voting_system");

if (!$conn) {
    die("Database Connection Failed");
}
?>
